import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  base: "/adel/frontend/blog/",  
})
// server: {
  //   proxy: {
    //     '/adel/frontend/blog/': 'http://192.168.1.219/',  
    //   }
    // },
    // "homepage": "/adel/frontend/blog/",
// https://vite.dev/config/