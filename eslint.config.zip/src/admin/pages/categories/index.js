export { default as CategoriesIndex } from "./categoryIndex";
export { default as CategoriesCreate } from "./categoryCreate";
export { default as CategoriesEdit } from "./categoryEdit";
