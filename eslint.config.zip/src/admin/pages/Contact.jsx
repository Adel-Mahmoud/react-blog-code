import React from "react";

const Contact = () => {
  return (
    <>
      <p>Contact</p>
    </>
  );
};

export default Contact;