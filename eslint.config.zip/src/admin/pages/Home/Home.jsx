import React, { useState, useEffect } from "react";

const Home = () => {

  return (
    <div className="container mt-4">
      <h1>Welcome to the Home Page</h1>
      
    </div>
  );
  
};

export default Home;
