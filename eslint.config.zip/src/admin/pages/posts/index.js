export { default as PostsIndex } from "./postIndex";
export { default as PostsCreate } from "./postCreate";
export { default as PostsEdit } from "./postEdit";
