import React from "react";

const Footer = () => {
  return (
    <>
      <p></p>
    </>
  );
};

export default Footer;
